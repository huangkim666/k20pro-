Changelog:

Version 2:
- Remove sth
