#!/system/bin/sh

ui_print " "
ui_print "Dual Speaker Mod For Redmi K20 Pro"
ui_print " "
ui_print "By acervenky@Kim"
ui_print " "
ui_print "Installed Successfully!"
